<?php
/**
 * Bootstrap Mapping Tab
 */
?>
<div class="stock-bootstrap-panel">
    <h2><?php _e('Bootstrap Mapping', 'stock-sync'); ?></h2>
    <p><?php _e('Upload a price list to automatically match products by name. Review and confirm matches to populate supplier references.', 'stock-sync'); ?></p>

    <form id="stock-bootstrap-form" method="post" enctype="multipart/form-data" class="stock-upload-form">
        <?php wp_nonce_field('stock_sync_upload_action', 'stock_sync_upload_nonce'); ?>

        <table class="form-table">
            <tr>
                <th scope="row"><?php _e('XLSX File', 'stock-sync'); ?></th>
                <td>
                    <input type="file" name="xlsx_file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required />
                </td>
            </tr>
            <tr>
                <th scope="row"></th>
                <td>
                    <details class="stock-advanced-options">
                        <summary><?php _e('Advanced options', 'stock-sync'); ?></summary>
                        <div class="stock-advanced-inner">
                            <label for="header_label_ref"><?php _e('Header label for reference column', 'stock-sync'); ?></label>
                            <input type="text" id="header_label_ref" name="header_label_ref" placeholder="e.g. NR REF" />
                            <p class="description"><?php _e('Optional. Overrides the expected header label for the reference column.', 'stock-sync'); ?></p>
                            <label for="header_label_avail"><?php _e('Header label for availability column', 'stock-sync'); ?></label>
                            <input type="text" id="header_label_avail" name="header_label_avail" placeholder="e.g. STR. W KAT." />
                            <p class="description"><?php _e('Optional. Overrides the expected header label for the availability column.', 'stock-sync'); ?></p>
                        </div>
                    </details>
                </td>
            </tr>
        </table>

        <p class="submit">
            <button type="submit" class="button button-primary" id="stock-bootstrap-analyze">
                <?php _e('Analyze & Match', 'stock-sync'); ?>
            </button>
        </p>
    </form>

    <div id="stock-bootstrap-progress" class="stock-progress" style="display:none;">
        <p><?php _e('Analyzing... this may take a moment.', 'stock-sync'); ?></p>
    </div>

    <div id="stock-bootstrap-results" style="display:none;">
        <h3 id="bootstrap-results-title"><?php _e('Review Matches', 'stock-sync'); ?></h3>
        <p id="bootstrap-summary"></p>

        <table class="widefat striped stock-match-table">
            <thead>
                <tr>
                    <th><input type="checkbox" id="check-all-auto" aria-label="Select all entries" /></th>
                    <th><?php _e('Ref', 'stock-sync'); ?></th>
                    <th><?php _e('XLSX Name', 'stock-sync'); ?></th>
                    <th><?php _e('WC Product', 'stock-sync'); ?></th>
                    <th><?php _e('Confidence', 'stock-sync'); ?></th>
                    <th><?php _e('Status', 'stock-sync'); ?></th>
                </tr>
            </thead>
            <tbody id="bootstrap-matches-body">
            </tbody>
        </table>

        <details id="bootstrap-unmatched-details" class="stock-unmatched-details">
            <summary id="bootstrap-unmatched-summary">
                <?php _e('Unmatched positions', 'stock-sync'); ?>
                <span class="stock-unmatched-count"></span>
            </summary>
            <table class="widefat striped stock-match-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="check-all-unmatched" aria-label="Select all unmatched entries" /></th>
                        <th><?php _e('Ref', 'stock-sync'); ?></th>
                        <th><?php _e('XLSX Name', 'stock-sync'); ?></th>
                        <th><?php _e('WC Product', 'stock-sync'); ?></th>
                        <th><?php _e('Confidence', 'stock-sync'); ?></th>
                        <th><?php _e('Status', 'stock-sync'); ?></th>
                    </tr>
                </thead>
                <tbody id="bootstrap-unmatched-body">
                </tbody>
            </table>
        </details>

        <p class="submit">
            <button type="button" class="button button-primary" id="stock-bootstrap-save" disabled>
                <?php _e('Confirm & Save Mappings', 'stock-sync'); ?>
            </button>
        </p>
    </div>
</div>
