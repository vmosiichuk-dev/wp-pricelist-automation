<?php
/**
 * Sync Log Tab
 */
$logger     = new StockSync_Change_Logger();
$sync_runs  = $logger->get_sync_runs(20);
?>
<div class="stock-log-panel">

    <div class="stock-info-banner">
        <div class="stock-info-content">
            <h2 class="stock-info-title"><?php _e('Sync Log', 'stock-sync'); ?></h2>
            <div class="stock-info-text">
                <ul>
                    <li><?php _e('Review past sync operations and their outcomes', 'stock-sync'); ?></li>
                    <li><?php _e('See how many products were updated, not found, or caused errors', 'stock-sync'); ?></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="stock-card">
        <h2 class="stock-card-title"><?php _e('Sync Log', 'stock-sync'); ?></h2>

        <?php if (empty($sync_runs)) : ?>
            <div class="stock-log-empty">
                <div class="stock-log-empty-icon">&#128203;</div>
                <p><?php _e('No sync operations logged yet. Run your first sync to see results here.', 'stock-sync'); ?></p>
            </div>
        <?php else : ?>
            <table class="stock-card-table">
                <thead>
                    <tr>
                        <th><?php _e('Date', 'stock-sync'); ?></th>
                        <th><?php _e('Distributor', 'stock-sync'); ?></th>
                        <th><?php _e('Total Changes', 'stock-sync'); ?></th>
                        <th><?php _e('Unavailable', 'stock-sync'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sync_runs as $run) : ?>
                        <tr>
                            <td><?php echo esc_html($run['run_date']); ?></td>
                            <td><?php echo esc_html($run['distributor_slug']); ?></td>
                            <td><?php echo intval($run['total_changes']); ?></td>
                            <td><?php echo intval($run['unavailable_count']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
