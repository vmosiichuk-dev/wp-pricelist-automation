<?php
/**
 * Main admin page wrapper
 */
?>
<div class="wrap stock-sync-wrap">

    <div class="stock-header-card">
        <div class="stock-header-meta">
            <div>
                <h1 class="stock-header-title"><?php echo esc_html(get_admin_page_title()); ?></h1>
                <p class="stock-header-tagline"><?php _e('Automate product availability from distributor price lists', 'stock-sync'); ?></p>
            </div>
            <form method="get" class="stock-header-distributor">
                <input type="hidden" name="page" value="stock-sync" />
                <input type="hidden" name="tab" value="<?php echo esc_attr($active_tab); ?>" />
                <label for="stock-distributor"><?php _e('Distributor', 'stock-sync'); ?></label>
                <select id="stock-distributor" name="distributor" onchange="this.form.submit()">
                    <?php foreach ($distributors as $slug => $name) : ?>
                        <option value="<?php echo esc_attr($slug); ?>" <?php selected($current_dist, $slug); ?>>
                            <?php echo esc_html($name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
        <div class="stock-header-tabs">
            <a href="<?php echo esc_url(admin_url('admin.php?page=stock-sync&tab=sync&distributor=' . $current_dist)); ?>"
               class="<?php echo $active_tab === 'sync' ? 'active' : ''; ?>">
                <?php _e('Sync Products', 'stock-sync'); ?>
            </a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=stock-sync&tab=test&distributor=' . $current_dist)); ?>"
               class="<?php echo $active_tab === 'test' ? 'active' : ''; ?>">
                <?php _e('Test Product', 'stock-sync'); ?>
            </a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=stock-sync&tab=log&distributor=' . $current_dist)); ?>"
               class="<?php echo $active_tab === 'log' ? 'active' : ''; ?>">
                <?php _e('Sync Log', 'stock-sync'); ?>
            </a>
        </div>
    </div>

    <div class="stock-tab-content">
        <?php
        $allowed_tabs = [
            'sync' => 'tab-sync.php',
            'test' => 'tab-test.php',
            'log'  => 'tab-log.php',
        ];
        $view_file = isset($allowed_tabs[$active_tab]) ? $allowed_tabs[$active_tab] : 'tab-sync.php';
        include STOCK_SYNC_PLUGIN_DIR . 'admin/views/' . $view_file;
        ?>
    </div>
</div>
